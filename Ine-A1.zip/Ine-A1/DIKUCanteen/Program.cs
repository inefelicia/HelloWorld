﻿namespace DIKUCanteen;
using System;

class Program {

    static void Main(string[] args) {
        Canteen canteen = new Canteen("DIKU"); //needs a name because Canteeen inherits from Room, which has a constructor that takes a name to set in the name field
        //Console.WriteLine("Hello World");
        Console.WriteLine(canteen);

        //instantiating some students
        Student stu1 = new("Ine", "Student", 22);
        Student stu2 = new("Helle", "Student", 25);
        Student stu3 = new("Freja", "Student", 23);
        Student stu4 = new("Mille", "Student", 22);

        //instantiating some CanteenBoardMemebers
        CanteenBoardMember canteenboardmember1 = new("Philipe", "Teacher", 43);
        CanteenBoardMember canteenboardmember2 = new("Mikkel", "Professor", 39);
        CanteenBoardMember canteenboardmember3 = new("Laura", "Ph.D.", 35);

        //instantiating a Canteen
        Canteen canteen1 = new Canteen("DIKUCanteen", 0);
        Canteen canteen2 = new Canteen("Niels Borh Canteen", 5);

        //showing that it works that both students and canteenboard members take cups
        Console.WriteLine("Student which takes a cup: " + stu1.Name + ", and number of cups before student takes cups: " + canteen2.Cups);
        stu1.TakeCup(canteen2);
        Console.WriteLine("Number of cups in the canteen " + canteen2.Name + " after " + stu1.Name + " has taken 1 cup: " + canteen2.Cups);
        Console.WriteLine("CanteenBoardMember which takes a cup: " + canteenboardmember1.Name + ", and number of cups before canteenboardmember takes 1 cup: " + canteen2.Cups);
        canteenboardmember1.TakeCup(canteen2);
        Console.WriteLine("Number of cups in the canteen " + canteen2.Name + " after " + canteenboardmember1.Name + " has taken 1 cup: " + canteen2.Cups);

        //showing that one cannot take cups when cups = 0
        Console.WriteLine("Number of cups before trying to take a cup: " + canteen1.Cups);
        stu4.TakeCup(canteen1);
        Console.WriteLine("Cups remaining in canteen after " + stu4.Name + " tries to take a cup when cups = 0: " + canteen1.Cups);

        Console.WriteLine("Number of cups before trying to take a cup: " + canteen1.Cups);
        canteenboardmember2.TakeCup(canteen1);
        Console.WriteLine("Cups remaining in canteen after " + canteenboardmember2.Name + " tries to take a cup when cups = 0: " + canteen1.Cups);


        //showing that it works to retun cups for students and canteenboard members
        Console.WriteLine("Student wants to return a cup: " + stu1.Name);
        Console.WriteLine("The number of cups in " + canteen2.Name + " before student " + stu1.Name + " has returned a cup: " + canteen2.Cups);
        stu1.ReturnCup(canteen2);
        Console.WriteLine("The number of cups in " + canteen2.Name + " after student " + stu1.Name + " has returned a cup: " + canteen2.Cups);
        Console.WriteLine("CanteenBoardMember which wants to return a cup: " + canteenboardmember1.Name);
        canteenboardmember1.ReturnCup(canteen2);
        Console.WriteLine("The number of cups in " + canteen2.Name + " after canteenboardmember " + canteenboardmember1.Name + " has returned a cup: " + canteen2.Cups);

        //showing that a Canteenboardmember can buy more cups 
        Console.WriteLine("Number of cups in " + canteen2.Name + "before buying 1 cup: " + canteen2.Cups + " and budget before buying: " + CanteenBoardMember.CupBudget);
        canteenboardmember3.BuyCup(canteen2);
        Console.WriteLine("Number of cups in " + canteen2.Name + " after buying 1 cup: " + canteen2.Cups + " and budget after buying: " + CanteenBoardMember.CupBudget);
        canteenboardmember3.BuyCup(canteen2);
        Console.WriteLine("Number of cups in  " + canteen2.Name + " after buying 1 more cup: " + canteen2.Cups + " and budget after buying: " + CanteenBoardMember.CupBudget);
    }
}

