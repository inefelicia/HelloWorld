namespace DIKUCanteen;

public class Student : Person {

    public Student(string name, string occupation, int age) : base(name, occupation, age) {

    }

    public bool HasCup = false;

    public void TakeCup(Canteen canteen) {
        if (HasCup == false && canteen.Cups > 0) {
            canteen.CupTaken();
            HasCup = true;
        }
    }

    public void ReturnCup(Canteen canteen) {
        if (HasCup == true) {
            canteen.CupReturned();
            HasCup = false;
        }
    }
}
