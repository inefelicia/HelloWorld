namespace DIKUCanteen;

public class Canteen : Room {
    public Canteen(string name) : base(name) {

    }

    private int cups = 100;

    public Canteen(string name, int cups) : base(name) {
        this.cups = cups;

    }

    public int Cups {
        get {
            return cups;
        }
    }

    public override string ToString() {
        return "Name: " + Name + " and current amount of cups: " + cups;
    }

    public void CupTaken() {
        cups--;

    }
    public void CupReturned() {
        cups++;
    }
}

