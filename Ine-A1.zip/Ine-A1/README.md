# SU-A1-StudentTemplate
Template for assignment 1 in the course. 

Name: Ine Felicia Ertesvåg Åsheim
Ku-ID: cdf313

Git: https://github.com/DIKU-SU/a1-inefelicia

To run my program, use dotnet build and dotnet run.

I have used the generative AI tool ChatGPT 5.0 with prompts to understand errors:

Prompt 1: "jeg får den her fejlkode: error CS1520: Method must have a return type. hvad betyder det?"

Prompt 2: "hvorfor får jeg de her warnings når jeg kører mit program? EolTargetFrameworks.targets(32,5): warning NETSDK1138: The target framework 'net7.0' is out of support and will not receive security updates in the future. Please refer to https://aka.ms/dotnet-core-support for more information about the support policy. /usr/local/share/dotnet/sdk/9.0.305/Sdks/Microsoft.NET.Sdk/targets/Microsoft.NET.EolTargetFrameworks.targets(32,5): warning NETSDK1138: The target framework 'net7.0' is out of support and will not receive security updates in the future. Please refer to https://aka.ms/dotnet-core-support for more information about the support policy. /usr/local/share/dotnet/sdk/9.0.305/Sdks/Microsoft.NET.Sdk/targets/Microsoft.NET.EolTargetFrameworks.targets(32,5): warning NETSDK1138: The target framework 'net7.0' is out of support and will not receive security updates in the future. Please refer to https://aka.ms/dotnet-core-support for more information about the support policy."

Prompt 3: "Hva betyder den her error CS1001"

Prompt 4: "Hva betyder de her fejlkoder: /Users/inef2503gmail.com/HelloWorld/a1-inefelicia/DIKUCanteen/Student.cs(16,9): error CS0103: The name 'cups' does not exist in the current context /Users/inef2503gmail.com/HelloWorld/a1-inefelicia/DIKUCanteen/Student.cs(16,16): error CS0103: The name 'cups' does not exist in the current context"

Prompt 5: "hva betyr dette error CS1503: Argument 3: cannot convert from 'int' to 'string'"

My use of AI focues on errors and warnings, which sometime sare confusing, and sometimes may be misleading, as sometimes the error said that I was missing a comma, but then it was actually a plus.